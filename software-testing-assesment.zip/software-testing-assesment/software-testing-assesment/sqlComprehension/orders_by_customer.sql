SELECT SHIPPER_ID FROM shippers
WHERE company_name = 'United Package'

SELECT c.customer_id,c.contact_name FROM customers c JOIN orders o on c.customer_id = o.customer_id
WHERE company_name ='Simons bistro'
AND ship_via = 2