SELECT COUNT(customer_id)
	FROM public.customers;