import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static org.junit.Assert.assertEquals;


public class checkout_page {
    WebDriver driver;
    public checkout_page(WebDriver driver){
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }
    @FindBy(id = "first-name")
    WebElement firstname;
    @FindBy(id = "last-name")
    WebElement lastname;
    @FindBy(id = "postal-code")
    WebElement zipCode;

    @FindBy(id = "continue")
    WebElement btnContinue;

    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[5]")
    WebElement lnkPrice;

    @FindBy(id = "finish")
    WebElement btnFinish;

    @FindBy(xpath = "//*[@id=\"checkout_summary_container\"]/div/div[2]/div[5]")
    WebElement itemTotal;



    public void checkOut(String name, String surname, String code, String firstPrice, String secondPrice) throws InterruptedException {
        firstname.sendKeys(name);
        lastname.sendKeys(surname);
        zipCode.sendKeys(code);
        btnContinue.click();
        System.out.println(firstPrice + "  " + secondPrice);
        Double firstP = Double.parseDouble(firstPrice.replace("$",""));
        Double secondP = Double.parseDouble(secondPrice.replace("$",""));

        System.out.println(firstP + secondP);
        String priceApp = lnkPrice.getText();
        Double priceCom = Double.parseDouble(priceApp.replace("Item total: $",""));
        assertEquals(priceCom, 39.98,0.0);

        btnFinish.click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains("THANK YOU FOR YOUR ORDER"));
    }
}
