import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class Tester {

    WebDriver driver;
    login_page login_page;
    home_page home_page;
    checkout_page checkout_page;
    List<String> prices = new ArrayList<>();
    @BeforeClass
    public void setup(){

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        login_page = new login_page(driver);
        home_page = new home_page(driver);
        checkout_page = new checkout_page(driver);
    }
    @Test(priority = 1)
    public void login(){

        boolean pass = login_page.login("standard_user", "secret_sauce");
        Assert.assertTrue(pass);
    }

    @Test(priority = 2)
    public void addToCart(){
        prices = home_page.addToCart();
    }

    @Test(priority = 3)
    public void checkout() throws InterruptedException {
        checkout_page.checkOut("Thato", "Thetele", "1632", prices.get(0), prices.get(1));
    }
}
